package sid.testeMaven1;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
       
       MongoRead mR = new MongoRead();
      mR.connectMongo();
        
        	
        while(true) {
        	
        	try {
        		mR.readDocuments();
    			try{
    				System.out.println("dormindo");
    				Thread.sleep(30000);
    			} catch (InterruptedException  e) {
    				Thread.currentThread().interrupt();
    				System.out.println("acordou");
    			}

        	} catch (Exception e) {
        		e.printStackTrace();
        	
        	}
        }
    }
}
