package migration;

import java.sql.Timestamp;
import java.util.List;
import java.util.Map;

import org.bson.Document;
import org.bson.types.ObjectId;

import com.mongodb.*;
import com.mongodb.client.MongoClient;

/**
 * Date: May 13 2019
 * This is a simple application that migrates data from a MongoDB database to a MySQL.
 * Data refers to measurements.
 * @author Joao Estevao
 * @version 1.0
 *
 *
 */



public class MongoRead   {

	/**
	 * MongoDB database client object
	 */
	private DB db;
	/**
	 * SQL object
	 */
	private SQLWrite sql;

	

	/**
	 * This method creates a MongoDB connection, and creates an instance of SQLWrite object
	 * It´s important to check if the port number, and database name is the desired one
	 */
	public void connectMongo() {
		com.mongodb.MongoClient mongoClient = new com.mongodb.MongoClient("localhost", 27017);
		db = mongoClient.getDB("sid");
		System.out.println("Mondo connected");
		sql=new SQLWrite();
	}

	/**This method iterates the mongoDB database collection, calls the method wich inserts the data in mysql
	 * 
	 * @throws Exception
	 */
	public  void readDocuments() throws Exception {
		try {
			System.out.println("vai comecar a ler");


			DBCollection coll = db.getCollection("Sensor");

			BasicDBObject whereQuery = new BasicDBObject();
			whereQuery.put("migracao", 0);
			BasicDBObject fields = new BasicDBObject();
			

			DBCursor cursor = coll.find(whereQuery, fields);
			while(cursor.hasNext()) {

				String objectId;
				Timestamp timestampDate;
				String tipoVariavel;
				double valorMedicao;


				System.out.println("eee");

				BasicDBObject medicaoBD = (BasicDBObject) cursor.next();
				System.out.println(medicaoBD);
				System.out.println("no such element");
				ObjectId id = (ObjectId)medicaoBD.get("_id");
				objectId = id.toString();
				System.out.println("ID: " + objectId);


				//retira o tipo da variavel
				tipoVariavel = medicaoBD.getString("id_sensor");
				System.out.println("variavel: " +tipoVariavel);


				//retirao valor da medicao
				String valorString = medicaoBD.getString("variavel");
				valorMedicao =  Double.parseDouble(valorString);
				System.out.println(valorMedicao);


				//retira a data e hora da medicao
				String horaData =   medicaoBD.getString("TimeStamp");
				System.out.println(horaData);
				timestampDate = Timestamp.valueOf(horaData);
				System.out.println("hora: " +timestampDate);




				int idVariavel;
				if(tipoVariavel.equals("Luminosidade")) {
					idVariavel=0;
				}else {
					idVariavel=1;
				}

				Medicao novaMedicao= new Medicao(valorMedicao, timestampDate, tipoVariavel, objectId, idVariavel );
				System.out.println(novaMedicao);
				updateDocument(id, coll, novaMedicao);
				SQLWrite.insertMedicoes(novaMedicao);




			}

		}catch(Exception e){
			System.out.println(e);
			
			readDocuments();
		}

	}

	/**This method searches the object, and updates the field medicao
	 * @param id Document from MongoDB
	 * @param coll MongoDB collection
	 * @param medicao instance of Medicao
	 */
	public void updateDocument(ObjectId id, DBCollection coll, Medicao medicao){


		System.out.println("updating");
		BasicDBObject document = new BasicDBObject();
		document.put("id_sensor", medicao.getTipoVariavel());
		document.put("variavel", medicao.getValorMedicao());
		document.put("TimeStamp", medicao.getData());
		document.put("migracao", 1);

		BasicDBObject searchQuery = new BasicDBObject().append("_id", id);

		coll.update(searchQuery, document);
		System.out.println("updated");

	}


}
