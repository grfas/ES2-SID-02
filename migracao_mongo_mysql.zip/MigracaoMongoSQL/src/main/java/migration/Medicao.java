package migration;

import java.sql.Timestamp;

public class Medicao {

	private double valorMedicao;
	private Timestamp data;
	private String tipoVariavel;
	private String idMedicao;
	private int idVariavel;
	
	public Medicao(double valor, Timestamp time, String tipo, String id, int idVar) {
		this.valorMedicao=valor;
		this.data=time;
		this.tipoVariavel=tipo;
		this.idMedicao=id;
		this.idVariavel=idVar;
		
	}

	public double getValorMedicao() {
		return valorMedicao;
	}

	public void setValorMedicao(double valorMedicao) {
		this.valorMedicao = valorMedicao;
	}

	public Timestamp getData() {
		return data;
	}

	public void setData(Timestamp data) {
		this.data = data;
	}

	public String getTipoVariavel() {
		return tipoVariavel;
	}

	public void setTipoVariavel(String tipoVariavel) {
		this.tipoVariavel = tipoVariavel;
	}

	public String getIdMedicao() {
		return idMedicao;
	}

	public void setIdMedicao(String idMedicao) {
		this.idMedicao = idMedicao;
	}
	
	public int getIdVariavel() {
		return idVariavel;
	}

	public void setIdVariavel(int idVar) {
		this.idVariavel = idVar;
	}

	
	
}
