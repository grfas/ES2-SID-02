package migration;

/**
 * This application reads throw MongoDB database, for unmigrated data, migrates it, and sleeps for 30 s
 * as the sensors will add more documents to our collection 'medicoes'
 *
 */
public class App 
{
    public static void main( String[] args )
    {
       
       MongoRead mR = new MongoRead();
      mR.connectMongo();
        
        	
        while(true) {
        	
        	try {
        		mR.readDocuments();
    			try{
    				Thread.sleep(30000);
    			} catch (InterruptedException  e) {
    				Thread.currentThread().interrupt();
    			}

        	} catch (Exception e) {
        		e.printStackTrace();
        	
        	}
        }
    }
}
