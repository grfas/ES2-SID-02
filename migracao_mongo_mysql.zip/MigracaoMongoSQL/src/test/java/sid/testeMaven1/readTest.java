package sid.testeMaven1;

import static org.junit.Assert.*;

import org.junit.Test;

import migration.MongoRead;

public class readTest {

	@Test
	public void readTest() {
		MongoRead mR = new MongoRead();
		fail("Not yet implemented");
	}

}
